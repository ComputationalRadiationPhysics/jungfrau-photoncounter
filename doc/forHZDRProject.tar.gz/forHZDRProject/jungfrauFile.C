//#include "jungfrauCommonHeader.h"

#include <fstream>  // std::ifstream
#include <stdint.h>  // uint16_t
#include <ctime>  // clock
#include <iomanip> // std::setprecision

#include <time.h>
#include <sys/time.h>

class oneframe {

public:
  uint64_t framenumber;
  uint64_t bunchid;
  uint16_t imagedata[NCH];

};

class jungfrauFile {

 private:

 public:
  ifstream filebin; // file descriptor
  oneframe thisframe;
  long long int filebinSize; // need 64 bit
  clock_t filebinStart;
  clock_t filebinStop;
  struct  timeval tss,tsss; //for timing

  jungfrauFile() { // constructor

    cout << "jungfrauFile constructed" << endl;
    //cout << "sizeof(thisframe) " << sizeof(thisframe) << endl;
    //cout << "address of data array " <<  &(thisframe.imagedata)<< endl;

  }
  
  uint16_t * getFrameDataHandle() {

    return (uint16_t*)&(thisframe.imagedata);

  }

  bool readNextFrame() {
 
    if (filebin.is_open()) {
      if (!filebin.eof()) {
	filebin.read(((char*)&thisframe),sizeof(thisframe));
	
	std::cout << std::fixed << std::setprecision(2)
		  << "\r   [" << std::string(int(filebin.tellg()*10 / float(filebinSize)), '#')
		  << std::string(10 + 1 - int(filebin.tellg()*10 / float(filebinSize)), ' ') 
		  << "] " << 100 * filebin.tellg() / float(filebinSize) << "%";

        if (filebin.good()) {return true;} // necessary to stop the frame 'after' the last frame returning true
	else {
	  filebinStop = clock();
	  double elapsed_secs = double(filebinStop - filebinStart) / CLOCKS_PER_SEC;
	  cout << " end of file reached in " << elapsed_secs << "s" << endl;
	  return false;
	}

      } else {
	filebinStop = clock();
	double elapsed_secs = double(filebinStop - filebinStart) / CLOCKS_PER_SEC;
	cout << " end of file reached in " << elapsed_secs << "s" << endl;
	
	return false;
      }
    } else {
      cout << "file not open" << endl;
      return false;
    }

  }

  int currentFrameNumber() {
 
    return int(thisframe.framenumber);

  }

  uint64_t currentBunchID() {
 
    return uint64_t(thisframe.bunchid);

  }

  void rewind() {
    if (filebin.is_open()) {
      cout << "rewinding file" << endl;
      filebin.clear();
      filebin.seekg(0);
    } else {
      cout << "file was not open" << endl;
    }
  }

  void open(char *fformat, int fileindex) {

    char fname[1000];
    sprintf(fname,fformat,fileindex);
    cout << "file name " << fname << endl;
    if (filebin.is_open()) {
      cout << "WARNING: a file is already open" << endl;
      cout << "WARNING: closing this file" << endl;
      filebin.close();
    }
    cout << "opening file" << endl;
    filebin.open((const char *)(fname), ios::in | ios::binary);
    filebin.seekg(0,filebin.end);
    filebinSize = filebin.tellg();
    filebin.seekg(0,filebin.beg);
    filebinStart = clock();
  }

  void close() {

    if (filebin.is_open()) {
      filebin.close();
      cout << "closed file" << endl;
    } else {
      cout << "file was not open" << endl;
    }

  }

  bool isOpen() {
    if (filebin.is_open()) {
      return true;
    } else {
      return false;
    }
  }

};
