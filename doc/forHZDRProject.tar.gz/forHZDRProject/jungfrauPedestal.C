#include "MovingStat.h"

#include "TCanvas.h"
#include "TH1F.h"
#include "TH2F.h"

class jungfrauPedestal {

private:
  MovingStat stat [NCH];

public:
  TH1F* pedestals1d;
  TH2F* pedestals2d;
  TH1F* pedestalvars1d;
  TH2F* pedestalvars2d;
  TH2F* pedestalsvars;

  jungfrauPedestal() {
    cout << "jungfrauPedestal constructed" << endl;
  }

  bool addFrameToPedestalCalculation(uint16_t *imagedata) {
    for (int i = 0; i<NCH; i++) {
      stat[i].Calc(double(imagedata[i]&0x3fff));
    }

    return true;
  }

  double pedestalOfChannel(int ichannel) {
    return stat[ichannel].Mean();
  }

  double rmsOfChannel(int ichannel) {
    return stat[ichannel].StandardDeviation();
  }

  bool pedestalData(double* pedestals) {
    for (int i = 0; i < NCH; i++) {
      pedestals[i] = stat[i].Mean();
    }
    return true;
  }

  bool pedestalData(uint16_t* pedestals) {
    for (int i = 0; i < NCH; i++) {
      pedestals[i] = uint16_t(round(stat[i].Mean()));
    }
    return true;
  }

  bool pedestalRMSData(double* pedestalRMSs) {
    for (int i = 0; i < NCH; i++) {
      pedestalRMSs[i] = stat[i].StandardDeviation();
    }
    return true;
  }

  int pedestalNFrames() {
    return stat[0].GetN();
  }

  void pedestalClear() {
    for (int i=0; i < NCH; i++){
      stat[i].Clear();
    }
  }

  bool pedestalSetNFrames(int nframes) {
    for (int i=0; i < NCH; i++){
      stat[i].SetN(nframes);
    }
    return true;
  }

  void savePedestals(uint16_t* pedestals, string fileName) {
    ofstream pedefile (fileName.c_str());
    if (pedefile.is_open()) {
      cout << "saving pedestals" << endl;
      for (int i=0; i<NCH; i++){
        pedefile << pedestals[i] << " " ;
      }
      pedefile.close();
    } else {
      cout << "Unable to open file" << endl;
    }
  }

  bool readPedestals(uint16_t* pedestals, string fileName) {
    ifstream pedefile(fileName.c_str());
    if (pedefile.is_open()) {
      cout << "reading pedestal file" << endl;
      for (int i = 0; i < NCH; i++) {
	pedefile >> pedestals[i];
      }
      return true;
    } else {
      cout << "Unable to open file" << endl;
      return false;
    }
  }

};
