#include<iostream>  // std::cout

// LoadPalette
#include "TColor.h"
#include "TStyle.h"
// jungfrauStyle
#include "TROOT.h"

#define NC 1024
#define NR 512
#define NCH NC*NR

using namespace std;
