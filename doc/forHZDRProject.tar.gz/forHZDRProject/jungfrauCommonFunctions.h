#ifndef JUNGFRAUCOMMONFUNCTIONS_H
#define JUNGFRAUCOMMONFUNCTIONS_H


int chipOfPixel(int i) { 
  int chip = 0;
  if (i/1024 >= 256 && i%1024 >= 0 && i%1024 < 256) {
    chip = 1;
  } else if (i/1024 >= 256 && i%1024 >= 256 && i%1024 < 512) {
    chip = 2;
  } else if (i/1024 >= 256 && i%1024 >= 512 && i%1024 < 768) {
    chip = 3;
  } else if (i/1024 >= 256 && i%1024 >= 768 && i%1024 < 1024) {
    chip = 4;
  } else if (i/1024 < 256 && i%1024 >= 0 && i%1024 < 256) {
    chip = 5;
  } else if (i/1024 < 256 && i%1024 >= 256 && i%1024 < 512) {
    chip = 6;
  } else if (i/1024 < 256 && i%1024 >= 512 && i%1024 < 768) {
    chip = 7;
  } else if (i/1024 < 256 && i%1024 >= 768 && i%1024 < 1024) {
    chip = 8;
  } else {
    cout << "problem" << endl;
  }
  return chip;
}


int supercolumnOfPixel(int i) {
  int sc = ((i-((i/256)*256))/64) + 1;
  return sc;
}


void LoadPaletteFalse() {

  // jet
  Double_t stops[5] = { 0.00, 0.34, 0.61, 0.84, 1.00 };
  Double_t red[5] = { 0.00, 0.00, 0.87, 1.00, 0.51 };
  Double_t green[5] = { 0.00, 0.81, 1.00, 0.20, 0.00 };
  Double_t blue[5] = { 0.51, 1.00, 0.12, 0.00, 0.00 };
  TColor::CreateGradientColorTable(5, stops, red, green, blue, 255, 1.0);
  gStyle->SetNumberContours(255);

}


void UsePaletteViridis() {

  // viridis 
  Double_t stops[9] = {0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
  Double_t red[9] = {26./255., 51./255., 43./255., 33./255., 28./255., 35./255., 74./255., 144./255., 246./255.};
  Double_t green[9] = {9./255., 24./255., 55./255., 87./255., 118./255., 150./255., 180./255., 200./255., 222./255.};
  Double_t blue[9] = {30./255., 96./255., 112./255., 114./255., 112./255., 101./255., 72./255., 35./255., 0./255.};
  TColor::CreateGradientColorTable(9, stops, red, green, blue, 255, 1.0);
  gStyle->SetNumberContours(255);

}


void UsePaletteDBR() {

  // dark body radiator
  Double_t stops[9] = {0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
  Double_t red[9] = {0./255., 45./255., 99./255., 156./255., 212./255., 230./255., 237./255., 234./255., 242./255.};
  Double_t green[9] = {0./255., 0./255., 0./255., 45./255., 101./255., 168./255., 238./255., 238./255., 243./255.};
  Double_t blue[9] = {0./255., 1./255., 1./255., 3./255., 9./255., 8./255., 11./255., 95./255., 230./255.};
  TColor::CreateGradientColorTable(9, stops, red, green, blue, 255, 1.0);
  gStyle->SetNumberContours(255);

}


void jungfrauStyle()
{
  gROOT->SetStyle("Plain"); /*Default white background for all plots*/
  /*set bkg color of all to white*/
  gStyle->SetCanvasColor(kWhite);
  gStyle->SetFrameFillColor(kWhite);
  gStyle->SetStatColor(kWhite);
  gStyle->SetPadColor(kWhite);
  gStyle->SetFillColor(10);
  gStyle->SetTitleFillColor(kWhite);
  
  /* SetPaperSize wants width & height in cm: A4 is 20,26 & US is 20,24*/
  gStyle->SetPaperSize(20, 26); 
  /* No yellow border around histogram*/
  gStyle->SetDrawBorder(0);
  /* remove border of canvas*/
  gStyle->SetCanvasBorderMode(0);
  /* remove border of pads*/
  gStyle->SetPadBorderMode(0);
  gStyle->SetFrameBorderMode(0);
  gStyle->SetLegendBorderSize(0);
  
  /* default text size*/
  gStyle->SetTextSize(0.05);
  gStyle->SetTitleSize(0.07,"xyz");
  gStyle->SetLabelSize(0.06,"xyz");
  /* title offset: distance between given text and axis, here x,y,z*/
  gStyle->SetLabelOffset(0.015,"xyz");
  gStyle->SetTitleOffset(1.1,"yz");
  gStyle->SetTitleOffset(1.0,"x");
  
  /* Use visible font for all text*/
  int font = 42; 
  gStyle->SetTitleFont(font);
  gStyle->SetTitleFontSize(0.06);
  gStyle->SetStatFont(font);
  gStyle->SetStatFontSize(0.07);
  gStyle->SetTextFont(font);
  gStyle->SetLabelFont(font,"xyz");
  gStyle->SetTitleFont(font,"xyz");
  gStyle->SetTitleBorderSize(0);
  gStyle->SetStatBorderSize(1);
  gStyle->SetLegendFont(font);

  /* big marker points*/
  gStyle->SetMarkerStyle(1);
  gStyle->SetLineWidth(2);  
  gStyle->SetMarkerSize(1.2);
  /*set palette in 2d histogram to nice and colorful one*/
  gStyle->SetPalette(1,0); 
  
  /*No title for histograms*/
  gStyle->SetOptTitle(0);
  /* show the errors on the stat box */
  gStyle->SetOptStat(0); 
  /* show errors on fitted parameters*/
  gStyle->SetOptFit(0); 
  /* number of decimals used for errors*/
  gStyle->SetEndErrorSize(5);   
  
  /* set line width to 2 by default so that histograms are visible when printed small
     idea: emphasize the data, not the frame around*/
  gStyle->SetHistLineWidth(2);
  gStyle->SetFrameLineWidth(2);
  gStyle->SetFuncWidth(2);
  gStyle->SetHistLineColor(kBlack);
  gStyle->SetFuncColor(kRed);
  gStyle->SetLabelColor(kBlack,"xyz");
  
  //set the margins
  gStyle->SetPadBottomMargin(0.2);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadRightMargin(0.05);
  gStyle->SetPadLeftMargin(0.2);
  
  //set the number of divisions to show
  gStyle->SetNdivisions(506, "xy");
  
  //turn off xy grids
  gStyle->SetPadGridX(0);
  gStyle->SetPadGridY(0);
  
  //set the tick mark style
  gStyle->SetPadTickX(1);
  gStyle->SetPadTickY(1);
  
  gStyle->SetCanvasDefW(800);
  gStyle->SetCanvasDefH(700);
  
  LoadPaletteFalse();

  gROOT->ForceStyle();
}

#endif /* JUNGFRAUCOMMONFUNCTIONS_H */
