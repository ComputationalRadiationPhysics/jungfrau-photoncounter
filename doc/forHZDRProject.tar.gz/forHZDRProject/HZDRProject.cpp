// file to document and produce the data sent to HZDR

// pede file at PSI
// /data_pool/px_101016/allpede_250us_1243__B_000000.dat

// data file at PSI
// /data_pool/px_101016/Insu_6_tr_1_45d_250us__B_000000.dat

// gain maps
// data/gainMaps_M022.bin 

// pede maps
// data/pedeMaps.bin

#include "jungfrauCommonHeader.h"
#include "jungfrauCommonFunctions.h"

#include "jungfrauFile.C"
#include "jungfrauPedestal.C"

struct GainMaps
{
  static double g0VALs[NCH]; // declaration, incomplete type
  static double g1VALs[NCH];
  static double g2VALs[NCH];
};

double GainMaps::g0VALs[NCH]; // definition, complete type
double GainMaps::g1VALs[NCH];
double GainMaps::g2VALs[NCH];

int main(int argc, char* argv[]) {
  jungfrauStyle();

  jungfrauFile *thisfile = new jungfrauFile();

  jungfrauPedestal *pedestalObject = new jungfrauPedestal();
  pedestalObject->pedestalSetNFrames(1000); // using 1000 frames, rolling window
  static uint16_t pedestals16_G0[NCH];
  static uint16_t pedestals16_G1[NCH];
  static uint16_t pedestals16_G2[NCH];

  float beamE = 12.4;

  TCanvas *mapcanvas = new TCanvas("mapcanvas","",150,10,800,400);
  mapcanvas->SetLeftMargin(0.09);
  mapcanvas->SetRightMargin(0.14);
  mapcanvas->SetTopMargin(0.08);
  mapcanvas->SetBottomMargin(0.15);

  TH2F* pedeG0_hist_2d = new TH2F("pedeG0_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* pedeG1_hist_2d = new TH2F("pedeG1_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* pedeG2_hist_2d = new TH2F("pedeG2_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);

  TH2F* pedeG0t_hist_2d = new TH2F("pedeG0t_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* pedeG1t_hist_2d = new TH2F("pedeG1t_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* pedeG2t_hist_2d = new TH2F("pedeG2t_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);

  TH2F* gainG0_hist_2d = new TH2F("gainG0_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* gainG1_hist_2d = new TH2F("gainG1_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* gainG2_hist_2d = new TH2F("gainG2_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);

  TH2F* gain_hist_2d = new TH2F("gain_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* adc_hist_2d = new TH2F("adc_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* adcpc_hist_2d = new TH2F("adcpc_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);
  TH2F* energy_hist_2d = new TH2F("energy_hist_2d","",NC,-0.5,NC-0.5,NR,-0.5,NR-0.5);


  // calculate pedestal (PSI location)
  thisfile->open((char*)"/data_pool/px_101016/allpede_250us_1243__B_%6.6d.dat", 0);

  for (int i = 0; i < 1000; i++) {
    thisfile->readNextFrame();
    pedestalObject->addFrameToPedestalCalculation(thisfile->getFrameDataHandle());
  }
  pedestalObject->pedestalData((uint16_t*)(&pedestals16_G0));
  pedestalObject->pedestalClear();

  for (int i = 0; i < 1000; i++) {
    thisfile->readNextFrame();
    pedestalObject->addFrameToPedestalCalculation(thisfile->getFrameDataHandle());
  }
  pedestalObject->pedestalData((uint16_t*)(&pedestals16_G1));
  pedestalObject->pedestalClear();
  
  for (int i = 0; i < 1000; i++) {
    thisfile->readNextFrame();
    pedestalObject->addFrameToPedestalCalculation(thisfile->getFrameDataHandle());
  }
  pedestalObject->pedestalData((uint16_t*)(&pedestals16_G2));
  pedestalObject->pedestalClear();
  thisfile->close();

  for (int i = 0; i < NCH; i++) {
    pedeG0_hist_2d->Fill(i%NC,i/NC,pedestals16_G0[i]);
    pedeG1_hist_2d->Fill(i%NC,i/NC,pedestals16_G1[i]);
    pedeG2_hist_2d->Fill(i%NC,i/NC,pedestals16_G2[i]);
  }

  // save pede map
  fstream outfilePede;
  outfilePede.open("data/pedeMaps.bin", ios::binary | ios::out);
  GainMaps *mapsObjectPede = new GainMaps;
  for (int i = 0; i < NCH; i++) {
    mapsObjectPede->g0VALs[i] = pedestals16_G0[i];
    mapsObjectPede->g1VALs[i] = pedestals16_G1[i];
    mapsObjectPede->g2VALs[i] = pedestals16_G2[i];
  }
  outfilePede.write((char*)mapsObjectPede->g0VALs, sizeof(mapsObjectPede->g0VALs));
  outfilePede.write((char*)mapsObjectPede->g1VALs, sizeof(mapsObjectPede->g1VALs));
  outfilePede.write((char*)mapsObjectPede->g2VALs, sizeof(mapsObjectPede->g2VALs));
  outfilePede.close();

  // get gain maps
  fstream infileGain;
  infileGain.open("data/gainMaps_M022.bin", ios::in | ios::binary);
  GainMaps *mapsObjectGain = new GainMaps;
  infileGain.read((char*)mapsObjectGain->g0VALs, sizeof(mapsObjectGain->g0VALs));
  infileGain.read((char*)mapsObjectGain->g1VALs, sizeof(mapsObjectGain->g1VALs));
  infileGain.read((char*)mapsObjectGain->g2VALs, sizeof(mapsObjectGain->g2VALs));
  infileGain.close();

  // test gain map
  for (int i = 0; i < NCH; i++) {
    gainG0_hist_2d->Fill(i%NC,i/NC,mapsObjectGain->g0VALs[i]);
    gainG1_hist_2d->Fill(i%NC,i/NC,mapsObjectGain->g1VALs[i]);
    gainG2_hist_2d->Fill(i%NC,i/NC,mapsObjectGain->g2VALs[i]);
  }

  gainG0_hist_2d->GetXaxis()->SetTitle("Column");
  gainG0_hist_2d->GetYaxis()->SetTitle("Row");
  gainG0_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  gainG0_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/gainG0_hist_2d_fromMap.png");

  gainG1_hist_2d->GetXaxis()->SetTitle("Column");
  gainG1_hist_2d->GetYaxis()->SetTitle("Row");
  gainG1_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  gainG1_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/gainG1_hist_2d_fromMap.png");
  
  gainG2_hist_2d->GetXaxis()->SetTitle("Column");
  gainG2_hist_2d->GetYaxis()->SetTitle("Row");
  gainG2_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  gainG2_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/gainG2_hist_2d_fromMap.png");

  // data (PSI location)
  thisfile->open((char*)"/data_pool/px_101016/Insu_6_tr_1_45d_250us__B_%6.6d.dat", 0);
  thisfile->readNextFrame();
  uint16_t* imagedptr = thisfile->getFrameDataHandle();

  for (int i = 0; i < NCH; i++) {

    uint16_t gain = (imagedptr[i]&0xc000) >> 14;
    int adc = imagedptr[i]&0x3fff;
    int adcpc = 0;
    float energy = 0.;
	
    if (gain == 0) {
      adcpc = adc - pedestals16_G0[i];
      energy = (adc - pedestals16_G0[i]) / mapsObjectGain->g0VALs[i];
    } else if (gain == 1) {
      adcpc = pedestals16_G1[i] - adc;
      energy = (-1)*(pedestals16_G1[i] - adc) / mapsObjectGain->g1VALs[i];
    } else if (gain == 3) {
      adcpc = pedestals16_G1[i] - adc;
      energy = (-1)*(pedestals16_G2[i] - adc) / mapsObjectGain->g2VALs[i];
    }

    gain_hist_2d->Fill(i%NC,i/NC,gain);
    adc_hist_2d->Fill(i%NC,i/NC,adc);
    adcpc_hist_2d->Fill(i%NC,i/NC,adcpc);
    energy_hist_2d->Fill(i%NC,i/NC,int((energy+(beamE/2.))/beamE));

  }

  thisfile->close();

  pedeG0_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG0_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG0_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG0_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG0_hist_2d.png");

  pedeG1_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG1_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG1_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG1_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG1_hist_2d.png");
  
  pedeG2_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG2_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG2_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG2_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG2_hist_2d.png");
  
  gain_hist_2d->GetXaxis()->SetTitle("Column");
  gain_hist_2d->GetYaxis()->SetTitle("Row");
  gain_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  gain_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/gain_hist_2d.png");
  gain_hist_2d->GetXaxis()->SetRangeUser(300,500);
  gain_hist_2d->GetYaxis()->SetRangeUser(400,500);
  gain_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/gain_hist_2d_zoom.png");

  adc_hist_2d->GetXaxis()->SetTitle("Column");
  adc_hist_2d->GetYaxis()->SetTitle("Row");
  adc_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  adc_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/adc_hist_2d.png");
  adc_hist_2d->GetXaxis()->SetRangeUser(300,500);
  adc_hist_2d->GetYaxis()->SetRangeUser(400,500);
  adc_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/adc_hist_2d_zoom.png");
  
  adcpc_hist_2d->GetXaxis()->SetTitle("Column");
  adcpc_hist_2d->GetYaxis()->SetTitle("Row");
  adcpc_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  adcpc_hist_2d->GetZaxis()->SetRangeUser(-1000,12000);
  adcpc_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/adcpc_hist_2d.png");
  adcpc_hist_2d->GetXaxis()->SetRangeUser(300,500);
  adcpc_hist_2d->GetYaxis()->SetRangeUser(400,500);
  adcpc_hist_2d->GetZaxis()->UnZoom();
  adcpc_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/adcpc_hist_2d_zoom.png");
  
  energy_hist_2d->GetXaxis()->SetTitle("Column");
  energy_hist_2d->GetYaxis()->SetTitle("Row");
  energy_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  energy_hist_2d->GetZaxis()->SetRangeUser(0,600);
  energy_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/energy_hist_2d.png");
  mapcanvas->SetLogz();
  mapcanvas->SaveAs("plots/energy_hist_2d_log.png");
  mapcanvas->SetLogz(0);
  energy_hist_2d->GetXaxis()->SetRangeUser(300,500);
  energy_hist_2d->GetYaxis()->SetRangeUser(400,500);
  energy_hist_2d->GetZaxis()->UnZoom();
  energy_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/energy_hist_2d_zoom.png");
  mapcanvas->SetLogz();
  mapcanvas->SaveAs("plots/energy_hist_2d_zoom_log.png");
  mapcanvas->SetLogz(0);
  
  // test pede map
  fstream infilePede;
  infilePede.open("data/pedeMaps.bin", ios::in | ios::binary);
  GainMaps *mapsObjectPede2 = new GainMaps;
  infilePede.read((char*)mapsObjectPede2->g0VALs, sizeof(mapsObjectPede2->g0VALs));
  infilePede.read((char*)mapsObjectPede2->g1VALs, sizeof(mapsObjectPede2->g1VALs));
  infilePede.read((char*)mapsObjectPede2->g2VALs, sizeof(mapsObjectPede2->g2VALs));
  infilePede.close();

  for (int i = 0; i < NCH; i++) {
    pedeG0t_hist_2d->Fill(i%NC,i/NC,mapsObjectPede2->g0VALs[i]);
    pedeG1t_hist_2d->Fill(i%NC,i/NC,mapsObjectPede2->g1VALs[i]);
    pedeG2t_hist_2d->Fill(i%NC,i/NC,mapsObjectPede2->g2VALs[i]);
  }

  pedeG0t_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG0t_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG0t_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG0t_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG0_hist_2d_fromMap.png");

  pedeG1t_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG1t_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG1t_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG1t_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG1_hist_2d_fromMap.png");
  
  pedeG2t_hist_2d->GetXaxis()->SetTitle("Column");
  pedeG2t_hist_2d->GetYaxis()->SetTitle("Row");
  pedeG2t_hist_2d->GetYaxis()->SetTitleOffset(0.7);
  pedeG2t_hist_2d->Draw("colz");
  mapcanvas->SaveAs("plots/pedeG2_hist_2d_fromMap.png");


}
